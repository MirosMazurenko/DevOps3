#ifndef FUNCA_H
#define FUNCA_H
class FuncA {
public:
    double compute(double x, int n);
};
#endif
